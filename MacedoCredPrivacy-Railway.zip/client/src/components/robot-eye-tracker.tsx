import { useEffect, useRef, useCallback } from "react";

export default function RobotEyeTracker() {
  const leftEyeRef = useRef<HTMLDivElement>(null);
  const rightEyeRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const updateRobotEyes = useCallback((event: MouseEvent) => {
    if (!containerRef.current || !leftEyeRef.current || !rightEyeRef.current) return;
    
    const containerRect = containerRef.current.getBoundingClientRect();
    const containerCenterX = containerRect.left + containerRect.width / 2;
    const containerCenterY = containerRect.top + containerRect.height / 2;
    
    const deltaX = event.clientX - containerCenterX;
    const deltaY = event.clientY - containerCenterY;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    // Smoother eye movement with reduced calculation
    const maxDistance = 80;
    const limitedDistance = Math.min(distance, maxDistance);
    const angle = Math.atan2(deltaY, deltaX);
    
    const eyeMoveX = Math.cos(angle) * (limitedDistance / maxDistance) * 3;
    const eyeMoveY = Math.sin(angle) * (limitedDistance / maxDistance) * 3;
    
    requestAnimationFrame(() => {
      if (leftEyeRef.current && rightEyeRef.current) {
        leftEyeRef.current.style.transform = `translate(${eyeMoveX}px, ${eyeMoveY}px)`;
        rightEyeRef.current.style.transform = `translate(${eyeMoveX}px, ${eyeMoveY}px)`;
      }
    });
  }, []);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    
    const throttledUpdate = (event: MouseEvent) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => updateRobotEyes(event), 16); // 60fps throttle
    };

    document.addEventListener('mousemove', throttledUpdate, { passive: true });
    return () => {
      document.removeEventListener('mousemove', throttledUpdate);
      clearTimeout(timeoutId);
    };
  }, [updateRobotEyes]);

  return (
    <div className="fixed bottom-8 right-8 z-40 group" ref={containerRef}>
      <div className="premium-card rounded-full p-6 shadow-2xl animate-float hover:scale-105 transition-all duration-300">
        <div className="relative w-16 h-16">
          {/* Robot Head */}
          <div className="w-16 h-16 premium-gradient rounded-full relative border-2 border-[#d4a017] shadow-xl">
            {/* Robot Eyes Container */}
            <div className="absolute top-4 left-3 w-3 h-3 bg-white rounded-full flex items-center justify-center shadow-inner">
              <div 
                ref={leftEyeRef}
                className="robot-eye w-2 h-2 bg-[#d4a017] rounded-full"
              />
            </div>
            <div className="absolute top-4 right-3 w-3 h-3 bg-white rounded-full flex items-center justify-center shadow-inner">
              <div 
                ref={rightEyeRef}
                className="robot-eye w-2 h-2 bg-[#d4a017] rounded-full"
              />
            </div>
            
            {/* Robot Details */}
            <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-[#d4a017] rounded-full opacity-80"></div>
            <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 w-4 h-1 bg-[#d4a017] rounded-full opacity-90"></div>
            
            {/* Simplified side panels */}
            <div className="absolute left-1 top-1/2 transform -translate-y-1/2 w-1 h-3 bg-[#d4a017] rounded-full opacity-50"></div>
            <div className="absolute right-1 top-1/2 transform -translate-y-1/2 w-1 h-3 bg-[#d4a017] rounded-full opacity-50"></div>
          </div>
          
          {/* Subtle glow effect */}
          <div className="absolute inset-0 w-16 h-16 bg-[#d4a017] rounded-full opacity-10 animate-pulse-slow -z-10"></div>
        </div>
        
        {/* Professional security badge */}
        <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 bg-green-600 text-white text-xs px-3 py-1 rounded-full font-bold shadow-lg border border-green-500">
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
            <span>SEGURO</span>
          </div>
        </div>
      </div>
    </div>
  );
}
