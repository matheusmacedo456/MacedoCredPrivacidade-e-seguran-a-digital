import { MessageCircle } from "lucide-react";

export default function FloatingWhatsApp() {
  return (
    <div className="fixed bottom-8 left-8 z-50 group">
      <a
        href="https://wa.me/5511984773513"
        target="_blank"
        rel="noopener noreferrer"
        className="relative flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full shadow-2xl premium-hover animate-pulse-slow"
        aria-label="WhatsApp - Fale Conosco"
      >
        <MessageCircle size={32} className="relative z-10" />
        
        {/* Glow effect */}
        <div className="absolute inset-0 bg-green-400 rounded-full opacity-30 animate-pulse-slow -z-10 scale-110"></div>
        
        {/* Ripple effect */}
        <div className="absolute inset-0 bg-green-400 rounded-full opacity-20 animate-ping -z-20"></div>
      </a>
      
      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-3 px-4 py-2 bg-[#002244] text-white text-sm rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
        Fale Conosco
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-[#002244]"></div>
      </div>
    </div>
  );
}
