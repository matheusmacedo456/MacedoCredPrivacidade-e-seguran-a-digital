import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { 
  Shield, 
  Search, 
  MessageCircle, 
  Target, 
  Lock, 
  RefreshCw, 
  UserCheck,
  Building,
  Phone,
  Mail,
  Home,
  CheckCircle,
  University,
  Headphones,
  Eye,
  Edit,
  XCircle,
  Download
} from "lucide-react";
import ScrollProgress from "@/components/scroll-progress";
import FloatingWhatsApp from "@/components/floating-whatsapp";
import RobotEyeTracker from "@/components/robot-eye-tracker";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: "easeOut" }
};

const staggerContainer = {
  initial: {},
  animate: {
    transition: {
      staggerChildren: 0.05
    }
  }
};

const cardHover = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-50px" },
  transition: { duration: 0.4, ease: "easeOut" }
};

export default function PrivacyPolicy() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-white relative overflow-hidden">
      <ScrollProgress />
      <FloatingWhatsApp />
      <RobotEyeTracker />

      {/* Background Elements */}
      <div className="fixed inset-0 pointer-events-none opacity-50">
        <div className="absolute top-20 right-20 w-64 h-64 bg-blue-100 rounded-full opacity-20 blur-2xl"></div>
        <div className="absolute bottom-20 left-20 w-48 h-48 bg-[#d4a017] rounded-full opacity-15 blur-2xl"></div>
      </div>

      {/* Header */}
      <header className="fixed w-full top-0 z-50 premium-card border-b border-blue-100">
        <div className="container mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="relative">
                <img 
                  src="https://macedocred-consignado.vercel.app/logo-removebg-preview%20(2).png" 
                  alt="MacedoCred Logo" 
                  className="h-14 w-auto drop-shadow-lg"
                />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse-slow border-2 border-white"></div>
              </div>
              <div className="border-l border-gray-300 pl-6">
                <h1 className="text-[#002244] font-bold text-2xl premium-text-shadow">MacedoCred</h1>
                <p className="text-sm text-gray-500 font-medium">Soluções Financeiras Premium</p>
                <div className="flex items-center space-x-2 mt-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-green-600 font-semibold">LGPD Compliant</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              {/* Security Badges */}
              <div className="hidden lg:flex items-center space-x-4">
                <div className="flex items-center space-x-2 bg-green-50 px-3 py-2 rounded-full border border-green-200">
                  <Shield size={16} className="text-green-600" />
                  <span className="text-sm font-semibold text-green-700">SSL</span>
                </div>
                <div className="flex items-center space-x-2 bg-blue-50 px-3 py-2 rounded-full border border-blue-200">
                  <CheckCircle size={16} className="text-blue-600" />
                  <span className="text-sm font-semibold text-blue-700">LGPD</span>
                </div>
                <div className="flex items-center space-x-2 bg-[#d4a017] bg-opacity-10 px-3 py-2 rounded-full border border-[#d4a017] border-opacity-30">
                  <University size={16} className="text-[#d4a017]" />
                  <span className="text-sm font-semibold text-[#002244]">BACEN</span>
                </div>
              </div>
              
              <a 
                href="https://macedocred-consignado.vercel.app"
                className="relative bg-gradient-to-r from-[#002244] to-[#003366] text-white px-8 py-3 rounded-full premium-hover shadow-lg hover:shadow-2xl flex items-center space-x-3 font-semibold"
              >
                <Home size={18} />
                <span>Site Principal</span>
                <div className="absolute inset-0 bg-white opacity-0 hover:opacity-10 rounded-full transition-opacity duration-300"></div>
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-36 pb-16 relative">
        {/* Hero Section */}
        <section className="container mx-auto px-6 text-center mb-20">
          <motion.div 
            className="max-w-5xl mx-auto"
            initial="initial"
            animate={isVisible ? "animate" : "initial"}
            variants={fadeInUp}
          >
            <div className="premium-card rounded-3xl p-12 mb-8">
              <div className="flex items-center justify-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-[#002244] to-[#003366] rounded-full flex items-center justify-center shadow-2xl">
                  <Shield className="text-[#d4a017]" size={40} />
                </div>
              </div>
              
              <h1 className="text-6xl font-bold text-[#002244] mb-8 premium-text-shadow">
                Política de <span className="text-[#d4a017] relative">
                  Privacidade
                  <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#d4a017] to-transparent rounded-full"></div>
                </span>
              </h1>
              
              <p className="text-2xl text-gray-600 mb-8 leading-relaxed font-light">
                Compromisso com a proteção dos seus dados pessoais e conformidade com a 
                <span className="font-semibold text-[#002244]"> LGPD</span>
              </p>
              
              <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
                <div className="flex items-center space-x-3 bg-blue-50 px-6 py-3 rounded-full">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-semibold text-gray-700">Última atualização: 22 de julho de 2025</span>
                </div>
                
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle size={16} className="text-green-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-600">LGPD</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Shield size={16} className="text-blue-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-600">SSL Seguro</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-[#d4a017] bg-opacity-20 rounded-full flex items-center justify-center">
                      <Lock size={16} className="text-[#d4a017]" />
                    </div>
                    <span className="text-sm font-medium text-gray-600">Criptografado</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Privacy Policy Section with Dark Background */}
        <section className="premium-gradient py-20 mb-16 relative">
          {/* Simplified background pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-10 left-10 w-20 h-20 border border-[#d4a017] rounded-full"></div>
            <div className="absolute bottom-10 right-10 w-24 h-24 border border-blue-400 rounded-full"></div>
          </div>
          
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-7xl mx-auto">
              <div className="text-center mb-20">
                <motion.div 
                  className="flex items-center justify-center mb-8"
                  {...cardHover}
                >
                  <div className="w-24 h-24 bg-gradient-to-br from-[#d4a017] to-yellow-600 rounded-full flex items-center justify-center shadow-2xl border-4 border-white border-opacity-20">
                    <Shield size={48} className="text-[#002244]" />
                  </div>
                </motion.div>

                <motion.h2 
                  className="text-5xl font-bold text-white mb-8 premium-text-shadow"
                  {...cardHover}
                >
                  Nossa Política de <span className="text-[#d4a017]">Proteção</span>
                </motion.h2>
                
                <motion.p 
                  className="text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed font-light"
                  {...cardHover}
                >
                  A MacedoCred respeita a privacidade dos seus clientes e está comprometida com a proteção dos dados pessoais fornecidos durante a prestação dos nossos serviços financeiros.
                </motion.p>
                
                <motion.div 
                  className="flex items-center justify-center space-x-8 mt-12"
                  {...cardHover}
                >
                  <div className="flex items-center space-x-3 bg-white bg-opacity-10 px-6 py-3 rounded-full backdrop-blur-sm">
                    <University size={20} className="text-[#d4a017]" />
                    <span className="text-white font-semibold">Banco Central</span>
                  </div>
                  <div className="flex items-center space-x-3 bg-white bg-opacity-10 px-6 py-3 rounded-full backdrop-blur-sm">
                    <CheckCircle size={20} className="text-green-400" />
                    <span className="text-white font-semibold">LGPD Compliant</span>
                  </div>
                  <div className="flex items-center space-x-3 bg-white bg-opacity-10 px-6 py-3 rounded-full backdrop-blur-sm">
                    <Lock size={20} className="text-blue-400" />
                    <span className="text-white font-semibold">SSL 256-bit</span>
                  </div>
                </motion.div>
              </div>

              {/* Company Info Card */}
              <motion.div 
                className="glassmorphism-dark rounded-3xl p-12 mb-16 premium-hover border border-[#d4a017] border-opacity-30"
                {...cardHover}
              >
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#d4a017] to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl">
                    <Building size={32} className="text-[#002244]" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#d4a017] mb-4">
                    Quem somos
                  </h3>
                  <div className="w-24 h-1 bg-gradient-to-r from-[#d4a017] to-transparent mx-auto rounded-full"></div>
                </div>
                
                <p className="text-blue-100 text-xl leading-relaxed mb-10 text-center font-light">
                  A MacedoCred atua na intermediação e consultoria dos seguintes serviços:
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-center space-x-4 bg-white bg-opacity-5 p-4 rounded-2xl hover:bg-opacity-10 transition-all duration-300">
                    <div className="w-12 h-12 bg-[#d4a017] bg-opacity-20 rounded-full flex items-center justify-center">
                      <span className="text-[#d4a017] text-2xl">💳</span>
                    </div>
                    <span className="text-white font-medium">Empréstimo consignado para beneficiários do INSS</span>
                  </div>
                  <div className="flex items-center space-x-4 bg-white bg-opacity-5 p-4 rounded-2xl hover:bg-opacity-10 transition-all duration-300">
                    <div className="w-12 h-12 bg-[#d4a017] bg-opacity-20 rounded-full flex items-center justify-center">
                      <span className="text-[#d4a017] text-2xl">🚗</span>
                    </div>
                    <span className="text-white font-medium">Financiamento de veículos</span>
                  </div>
                  <div className="flex items-center space-x-4 bg-white bg-opacity-5 p-4 rounded-2xl hover:bg-opacity-10 transition-all duration-300">
                    <div className="w-12 h-12 bg-[#d4a017] bg-opacity-20 rounded-full flex items-center justify-center">
                      <span className="text-[#d4a017] text-2xl">🏦</span>
                    </div>
                    <span className="text-white font-medium">Saque aniversário do FGTS</span>
                  </div>
                  <div className="flex items-center space-x-4 bg-white bg-opacity-5 p-4 rounded-2xl hover:bg-opacity-10 transition-all duration-300">
                    <div className="w-12 h-12 bg-[#d4a017] bg-opacity-20 rounded-full flex items-center justify-center">
                      <span className="text-[#d4a017] text-2xl">💰</span>
                    </div>
                    <span className="text-white font-medium">Empréstimos BPC/LOAS</span>
                  </div>
                </div>
              </motion.div>

              {/* Privacy Sections Grid */}
              <motion.div 
                className="grid md:grid-cols-2 lg:grid-cols-3 gap-10"
                variants={staggerContainer}
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
              >
                {/* Section 1: Data Collection */}
                <motion.div 
                  className="glassmorphism-dark rounded-3xl p-10 premium-hover group border border-[#d4a017] border-opacity-20"
                  variants={cardHover}
                >
                  <div className="text-center mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-[#d4a017] to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl group-hover:scale-110 transition-transform duration-300">
                      <Search className="text-[#002244]" size={32} />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Dados que coletamos</h3>
                    <div className="w-16 h-1 bg-gradient-to-r from-[#d4a017] to-transparent mx-auto rounded-full"></div>
                  </div>
                  <ul className="space-y-4">
                    <li className="flex items-center space-x-4 bg-white bg-opacity-5 p-3 rounded-xl hover:bg-opacity-10 transition-all duration-300">
                      <div className="w-8 h-8 bg-[#d4a017] bg-opacity-30 rounded-full flex items-center justify-center">
                        <span className="text-[#d4a017] text-lg">👤</span>
                      </div>
                      <span className="text-blue-100 font-medium">Nome completo</span>
                    </li>
                    <li className="flex items-center space-x-4 bg-white bg-opacity-5 p-3 rounded-xl hover:bg-opacity-10 transition-all duration-300">
                      <div className="w-8 h-8 bg-[#d4a017] bg-opacity-30 rounded-full flex items-center justify-center">
                        <Phone size={16} className="text-[#d4a017]" />
                      </div>
                      <span className="text-blue-100 font-medium">Telefone (WhatsApp)</span>
                    </li>
                    <li className="flex items-center space-x-4 bg-white bg-opacity-5 p-3 rounded-xl hover:bg-opacity-10 transition-all duration-300">
                      <div className="w-8 h-8 bg-[#d4a017] bg-opacity-30 rounded-full flex items-center justify-center">
                        <Mail size={16} className="text-[#d4a017]" />
                      </div>
                      <span className="text-blue-100 font-medium">E-mail</span>
                    </li>
                    <li className="flex items-center space-x-4 bg-white bg-opacity-5 p-3 rounded-xl hover:bg-opacity-10 transition-all duration-300">
                      <div className="w-8 h-8 bg-[#d4a017] bg-opacity-30 rounded-full flex items-center justify-center">
                        <span className="text-[#d4a017] text-sm font-bold">ID</span>
                      </div>
                      <span className="text-blue-100 font-medium">CPF e RG</span>
                    </li>
                  </ul>
                </motion.div>

                {/* Section 2: How Data is Collected */}
                <motion.div 
                  className="glassmorphism-dark rounded-2xl p-8 hover:transform hover:-translate-y-2 transition-all duration-300"
                  variants={cardHover}
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-[#d4a017] rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageCircle className="text-[#002244]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Como os dados são coletados</h3>
                  </div>
                  <p className="text-blue-100 mb-4">Os dados são coletados de forma voluntária por meio de:</p>
                  <ul className="space-y-3 text-blue-100">
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">💬</span>
                      <span>Contatos via WhatsApp</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">📱</span>
                      <span>Formulários ou mensagens em redes sociais</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Headphones size={16} className="text-[#d4a017]" />
                      <span>Atendimento presencial ou por telefone</span>
                    </li>
                  </ul>
                </motion.div>

                {/* Section 3: Purpose of Data Use */}
                <motion.div 
                  className="glassmorphism-dark rounded-2xl p-8 hover:transform hover:-translate-y-2 transition-all duration-300"
                  variants={cardHover}
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-[#d4a017] rounded-full flex items-center justify-center mx-auto mb-4">
                      <Target className="text-[#002244]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Para que usamos seus dados</h3>
                  </div>
                  <p className="text-blue-100 mb-4">Os dados pessoais são utilizados exclusivamente para:</p>
                  <ul className="space-y-3 text-blue-100">
                    <li className="flex items-center space-x-3">
                      <Phone size={16} className="text-[#d4a017]" />
                      <span>Entrar em contato com você</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">🧮</span>
                      <span>Realizar simulações e propostas de crédito</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle size={16} className="text-[#d4a017]" />
                      <span>Verificar elegibilidade aos serviços</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">⚖️</span>
                      <span>Cumprir exigências legais</span>
                    </li>
                  </ul>
                </motion.div>

                {/* Section 4: Data Security */}
                <motion.div 
                  className="glassmorphism-dark rounded-2xl p-8 hover:transform hover:-translate-y-2 transition-all duration-300"
                  variants={cardHover}
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-[#d4a017] rounded-full flex items-center justify-center mx-auto mb-4">
                      <Lock className="text-[#002244]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Segurança das informações</h3>
                  </div>
                  <p className="text-blue-100 mb-4">A MacedoCred adota medidas de segurança adequadas para proteger seus dados:</p>
                  <ul className="space-y-3 text-blue-100">
                    <li className="flex items-center space-x-3">
                      <Shield size={16} className="text-[#d4a017]" />
                      <span>Criptografia avançada</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">🛡️</span>
                      <span>Proteção contra acesso não autorizado</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">💾</span>
                      <span>Backup seguro</span>
                    </li>
                  </ul>
                </motion.div>

                {/* Section 5: Data Sharing */}
                <motion.div 
                  className="glassmorphism-dark rounded-2xl p-8 hover:transform hover:-translate-y-2 transition-all duration-300"
                  variants={cardHover}
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-[#d4a017] rounded-full flex items-center justify-center mx-auto mb-4">
                      <RefreshCw className="text-[#002244]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Compartilhamento de dados</h3>
                  </div>
                  <p className="text-blue-100 mb-4">Seus dados podem ser compartilhados com:</p>
                  <ul className="space-y-3 text-blue-100">
                    <li className="flex items-center space-x-3">
                      <University size={16} className="text-[#d4a017]" />
                      <span>Instituições financeiras parceiras</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="text-[#d4a017]">📈</span>
                      <span>Operadoras de crédito parceiras</span>
                    </li>
                  </ul>
                  <div className="bg-red-500 bg-opacity-20 border border-red-400 border-opacity-30 rounded-lg p-4 mt-4">
                    <p className="text-red-200 font-semibold flex items-center">
                      <span className="text-red-300 mr-2">⚠️</span>
                      Não vendemos seus dados a terceiros
                    </p>
                  </div>
                </motion.div>

                {/* Section 6: User Rights */}
                <motion.div 
                  className="glassmorphism-dark rounded-2xl p-8 hover:transform hover:-translate-y-2 transition-all duration-300"
                  variants={cardHover}
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-[#d4a017] rounded-full flex items-center justify-center mx-auto mb-4">
                      <UserCheck className="text-[#002244]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Seus direitos</h3>
                  </div>
                  <p className="text-blue-100 mb-4">De acordo com a LGPD, você tem direito a:</p>
                  <ul className="space-y-3 text-blue-100">
                    <li className="flex items-center space-x-3">
                      <Eye size={16} className="text-[#d4a017]" />
                      <span>Saber quais dados armazenamos</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Edit size={16} className="text-[#d4a017]" />
                      <span>Solicitar correção ou exclusão</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <XCircle size={16} className="text-[#d4a017]" />
                      <span>Retirar seu consentimento</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Download size={16} className="text-[#d4a017]" />
                      <span>Solicitar portabilidade dos dados</span>
                    </li>
                  </ul>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Trust & Statistics Section */}
        <section className="container mx-auto px-6 mb-16">
          <div className="max-w-7xl mx-auto">
            <motion.div 
              className="text-center mb-12"
              {...cardHover}
            >
              <h2 className="text-4xl font-bold text-[#002244] mb-4">Confiança e Transparência</h2>
              <p className="text-xl text-gray-600">Números que demonstram nossa credibilidade no mercado financeiro</p>
            </motion.div>

            <div className="grid md:grid-cols-4 gap-8 mb-16">
              <motion.div 
                className="premium-card rounded-2xl p-8 text-center premium-hover"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UserCheck className="text-white" size={24} />
                </div>
                <h3 className="text-3xl font-bold text-[#002244] mb-2">8.000+</h3>
                <p className="text-gray-600 font-medium">Clientes Atendidos</p>
              </motion.div>

              <motion.div 
                className="premium-card rounded-2xl p-8 text-center premium-hover"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#d4a017] to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="text-[#002244]" size={24} />
                </div>
                <h3 className="text-3xl font-bold text-[#002244] mb-2">98%</h3>
                <p className="text-gray-600 font-medium">Taxa de Aprovação</p>
              </motion.div>

              <motion.div 
                className="premium-card rounded-2xl p-8 text-center premium-hover"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <University className="text-white" size={24} />
                </div>
                <h3 className="text-3xl font-bold text-[#002244] mb-2">15+</h3>
                <p className="text-gray-600 font-medium">Anos de Experiência</p>
              </motion.div>

              <motion.div 
                className="premium-card rounded-2xl p-8 text-center premium-hover"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-white" size={24} />
                </div>
                <h3 className="text-3xl font-bold text-[#002244] mb-2">24h</h3>
                <p className="text-gray-600 font-medium">Aprovação Média</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="container mx-auto px-6 mb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h2 
              className="text-4xl font-bold text-[#002244] mb-8 flex items-center justify-center"
              {...cardHover}
            >
              <Headphones className="text-[#d4a017] mr-4" size={40} />
              Entre em Contato
            </motion.h2>
            <motion.p 
              className="text-xl text-gray-600 mb-12"
              {...cardHover}
            >
              Para qualquer dúvida sobre esta política ou sobre seus dados pessoais
            </motion.p>
            
            <div className="grid md:grid-cols-2 gap-8">
              <motion.div 
                className="premium-card rounded-2xl p-8 premium-hover group"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <MessageCircle className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-[#002244] mb-4">WhatsApp</h3>
                <p className="text-gray-600 mb-4">Atendimento instantâneo via WhatsApp</p>
                <a 
                  href="https://wa.me/5511984773513" 
                  className="inline-flex items-center space-x-2 bg-green-500 text-white px-6 py-3 rounded-full hover:bg-green-600 transition-colors font-semibold"
                >
                  <MessageCircle size={16} />
                  <span>(11) 98477-3513</span>
                </a>
              </motion.div>
              
              <motion.div 
                className="premium-card rounded-2xl p-8 premium-hover group"
                {...cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#002244] to-[#003366] rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Mail className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-[#002244] mb-4">E-mail</h3>
                <p className="text-gray-600 mb-4">Suporte técnico e dúvidas gerais</p>
                <a 
                  href="mailto:macedocred.sp@gmail.com" 
                  className="inline-flex items-center space-x-2 bg-[#002244] text-white px-6 py-3 rounded-full hover:bg-[#003366] transition-colors font-semibold"
                >
                  <Mail size={16} />
                  <span>macedocred.sp@gmail.com</span>
                </a>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="premium-gradient py-16 relative">
        {/* Minimal background pattern */}
        <div className="absolute inset-0 opacity-3">
          <div className="absolute top-10 left-10 w-16 h-16 border border-[#d4a017] rounded-full"></div>
          <div className="absolute bottom-10 right-10 w-20 h-20 border border-blue-400 rounded-full"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center">
            {/* Logo and Brand */}
            <motion.div 
              className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-6 mb-12"
              {...cardHover}
            >
              <div className="relative">
                <img 
                  src="https://macedocred-consignado.vercel.app/logo-removebg-preview%20(2).png" 
                  alt="MacedoCred Logo" 
                  className="h-20 w-auto drop-shadow-2xl"
                />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full animate-pulse-slow border-2 border-white"></div>
              </div>
              <div className="text-center md:text-left">
                <h3 className="text-4xl font-bold text-[#d4a017] premium-text-shadow">MacedoCred</h3>
                <p className="text-xl text-blue-200 font-light">Soluções Financeiras Premium</p>
                <div className="flex items-center justify-center md:justify-start space-x-2 mt-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-green-400 font-semibold">Online 24/7</span>
                </div>
              </div>
            </motion.div>
            
            {/* Security Badges */}
            <motion.div 
              className="grid md:grid-cols-4 gap-8 mb-16"
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              <motion.div 
                className="flex flex-col items-center space-y-3 glassmorphism-dark p-6 rounded-2xl premium-hover"
                variants={cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl">
                  <Shield className="text-white" size={24} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-white text-lg">Site Seguro</p>
                  <p className="text-sm text-green-400">SSL 256-bit</p>
                </div>
              </motion.div>
              
              <motion.div 
                className="flex flex-col items-center space-y-3 glassmorphism-dark p-6 rounded-2xl premium-hover"
                variants={cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#d4a017] to-yellow-600 rounded-full flex items-center justify-center shadow-2xl">
                  <CheckCircle className="text-[#002244]" size={24} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-white text-lg">LGPD</p>
                  <p className="text-sm text-[#d4a017]">100% Adequada</p>
                </div>
              </motion.div>
              
              <motion.div 
                className="flex flex-col items-center space-y-3 glassmorphism-dark p-6 rounded-2xl premium-hover"
                variants={cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-2xl">
                  <University className="text-white" size={24} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-white text-lg">Banco Central</p>
                  <p className="text-sm text-blue-400">Autorizada</p>
                </div>
              </motion.div>

              <motion.div 
                className="flex flex-col items-center space-y-3 glassmorphism-dark p-6 rounded-2xl premium-hover"
                variants={cardHover}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl">
                  <Lock className="text-white" size={24} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-white text-lg">Criptografia</p>
                  <p className="text-sm text-purple-400">Dados Seguros</p>
                </div>
              </motion.div>
            </motion.div>
            
            {/* Contact Links */}
            <motion.div 
              className="border-t border-blue-700 border-opacity-50 pt-12"
              {...cardHover}
            >
              <p className="text-blue-200 mb-8 text-lg">
                &copy; 2025 MacedoCred. Todos os direitos reservados.
              </p>
              <div className="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
                <a 
                  href="https://macedocred-consignado.vercel.app" 
                  className="bg-gradient-to-r from-[#d4a017] to-yellow-600 text-[#002244] px-8 py-4 rounded-full premium-hover font-bold flex items-center space-x-3 shadow-2xl"
                >
                  <Home size={20} />
                  <span>Acessar Site Principal</span>
                </a>
                
                <div className="flex space-x-4">
                  <a 
                    href="https://wa.me/5511984773513" 
                    className="bg-green-500 text-white p-4 rounded-full premium-hover shadow-2xl"
                    aria-label="WhatsApp"
                  >
                    <MessageCircle size={20} />
                  </a>
                  <a 
                    href="mailto:macedocred.sp@gmail.com" 
                    className="bg-blue-500 text-white p-4 rounded-full premium-hover shadow-2xl"
                    aria-label="E-mail"
                  >
                    <Mail size={20} />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </footer>
    </div>
  );
}
