# MacedoCred Privacy Policy Website

## Overview

This is a modern, single-page privacy policy website for MacedoCred, a Brazilian credit services company. The application is built with a full-stack TypeScript architecture using React for the frontend and Express.js for the backend, with a focus on creating an institutional, bank-like user experience similar to digital banks like Nubank, Inter, and C6 Bank.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Animations**: Framer Motion for smooth animations and transitions
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ESM modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Build Process**: esbuild for server-side bundling

### Design System
- **Color Scheme**: Custom MacedoCred brand colors (navy blue #002244 and gold #d4a017)
- **Typography**: Poppins font family for modern, banking-style appearance
- **Component Library**: Complete shadcn/ui implementation with custom theming
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints

## Key Components

### Core Pages
- **Privacy Policy Page**: Main landing page with comprehensive LGPD-compliant privacy policy
- **404 Not Found**: Error handling for invalid routes

### Interactive Components
- **Floating WhatsApp Button**: Persistent contact widget linking to WhatsApp
- **Robot Eye Tracker**: Animated mascot that follows mouse movement
- **Scroll Progress Indicator**: Visual progress bar showing page scroll position
- **Animated Sections**: Framer Motion-powered scroll-reveal animations

### UI Component System
- Complete shadcn/ui component library including:
  - Form components (inputs, selects, checkboxes, etc.)
  - Navigation components (menus, breadcrumbs, pagination)
  - Feedback components (alerts, toasts, progress indicators)
  - Layout components (cards, separators, tabs)
  - Data display components (tables, charts, badges)

## Data Flow

### Database Schema
- **Users Table**: Basic user management with username/password authentication
- **PostgreSQL Integration**: Configured for Neon Database with connection pooling
- **Migration System**: Drizzle Kit for database schema management

### State Management
- **Server State**: TanStack Query for API data fetching and caching
- **Local State**: React hooks for component-level state
- **Form Handling**: React Hook Form with Zod validation schemas

### API Structure
- **RESTful Design**: Express routes with `/api` prefix
- **Type Safety**: Shared TypeScript types between client and server
- **Error Handling**: Centralized error middleware with proper HTTP status codes

## External Dependencies

### Core Dependencies
- **Database**: `@neondatabase/serverless` for serverless PostgreSQL
- **ORM**: `drizzle-orm` and `drizzle-zod` for type-safe database operations
- **UI Framework**: Extensive Radix UI component suite
- **Animation**: `framer-motion` for advanced animations
- **Styling**: `tailwindcss` with additional plugins
- **Development**: Vite with React plugin and TypeScript support

### Development Tools
- **Type Checking**: TypeScript with strict configuration
- **Build Process**: Vite for frontend, esbuild for backend
- **Code Quality**: ESLint-ready configuration
- **Development Server**: Hot reload with Vite dev server

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite compiles React app to static assets in `dist/public`
2. **Backend Build**: esbuild bundles Express server to `dist/index.js`
3. **Database Migration**: Drizzle Kit handles schema updates via `db:push` command

### Environment Configuration
- **Development**: `NODE_ENV=development` with tsx for TypeScript execution
- **Production**: `NODE_ENV=production` with compiled JavaScript
- **Database**: `DATABASE_URL` environment variable for PostgreSQL connection

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Neon Database recommended)
- Static file serving capability for frontend assets
- Environment variable support for configuration

### Performance Optimizations
- **Code Splitting**: Vite handles automatic code splitting
- **Asset Optimization**: Automatic minification and compression
- **Database Optimization**: Connection pooling and prepared statements
- **Caching**: React Query provides intelligent client-side caching